import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

public class WhiteBoardPanel extends JPanel {
    private Graphics2D graphics2D;
    private BufferedImage image;;
    public WhiteBoardPanel(){
        this.setSize(800, 600);
        image = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);
        graphics2D = image.createGraphics();
        graphics2D.setColor(Color.WHITE);
        graphics2D.fillRect(0, 0, 800, 600);
        graphics2D.setColor(Color.BLACK);

    }

    public void assignImage(BufferedImage image){
        if (image != null){
            this.image = image;
            this.repaint();
        } else {
            this.image = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);
        }
    }

    public Graphics2D getGraphics2D() {
        return graphics2D;
    }

    public void setGraphics2D(Graphics2D graphics2D) {
        this.graphics2D = graphics2D;
    }

    public BufferedImage getImage() {
        return image;
    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }
}


