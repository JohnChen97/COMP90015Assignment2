import java.rmi.Remote;

public interface IRemoteChatBoard extends Remote {
}
