import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.*;

public class Client {

    public Client() {



        try {
//            RemoteWhiteBoard remoteWhiteBoard = (RemoteWhiteBoard) Naming.lookup("rmi://" + this.host + ":" + this.port + "/WhiteBoard");
            Registry registry = LocateRegistry.getRegistry("localhost", 8000);

            IRemoteWhiteBoard remoteMath = (IRemoteWhiteBoard) registry.lookup("RemoteWhiteBoardServer");

        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }


    }



    public static void main(String[] args) {

        String host = (args.length < 5) ? null : args[0];
        String port = (args.length < 5) ? null : args[1];
        String serviceName = (args.length < 5) ? null : args[2];

        String username = (args.length < 5) ? null : args[3];

        String password = (args.length < 5) ? null : args[4];
        Client client = new Client();
    }
}




