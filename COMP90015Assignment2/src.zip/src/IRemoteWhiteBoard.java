import javax.swing.*;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IRemoteWhiteBoard extends Remote {

    public void drawLine(int x1, int y1, int x2, int y2) throws RemoteException;

    public void draw(JPanel whiteBoardPanel, int x, int y) throws RemoteException;
}
