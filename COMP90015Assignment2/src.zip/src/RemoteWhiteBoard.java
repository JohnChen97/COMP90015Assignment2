import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class RemoteWhiteBoard extends UnicastRemoteObject implements IRemoteWhiteBoard{

    private JFrame frame;
    private WhiteBoardPanel whiteBoardPanel;

    public RemoteWhiteBoard() throws RemoteException {
        this.frame = new JFrame("Whiteboard");
        whiteBoardPanel = new WhiteBoardPanel();
        frame.add(whiteBoardPanel);
        whiteBoardPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                draw(whiteBoardPanel, e.getX(), e.getY());
            }
        });

        whiteBoardPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                draw(whiteBoardPanel, e.getX(), e.getY());
            }
        });

        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }

    @Override
    public void drawLine(int x1, int y1, int x2, int y2) throws RemoteException {
        Graphics2D g2 = this.whiteBoardPanel.getGraphics2D();
        BufferedImage image = this.whiteBoardPanel.getImage();
        g2.drawLine(x1, y1, x2, y2);
        whiteBoardPanel.getGraphics().drawImage(image, 0, 0, this.whiteBoardPanel);
    }

    public void draw(JPanel whiteBoardPanel, int x, int y) {
        Graphics2D g2 = this.whiteBoardPanel.getGraphics2D();
        BufferedImage image = this.whiteBoardPanel.getImage();
        g2.fillOval(x, y, 3, 3);
        whiteBoardPanel.getGraphics().drawImage(image, 0, 0, this.whiteBoardPanel);
    }

}
